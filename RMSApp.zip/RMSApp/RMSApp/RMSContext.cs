﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace RMSApp
{
    public class RMSContext : DbContext
    {
        public RMSContext(DbContextOptions options)
                    : base(options)
        {
        }
        //public DbSet<Users> Users { get; set; }
        //public DbSet<Candidates> Candidates { get; set; }
        //public DbSet<Roles> Roles { get; set; }
        //public DbSet<Rounds> Rounds { get; set; }
        //public DbSet<UserMappings> UserMappings { get; set; }
    }
}
