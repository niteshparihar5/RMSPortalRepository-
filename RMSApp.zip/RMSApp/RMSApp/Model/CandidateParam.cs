﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RMSApp
{
    public class CandidateParam
    {
        public int CandidateId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Mobile { get; set; }
        public string Address { get; set; }
        public string KeySkill { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }       
    }
}
