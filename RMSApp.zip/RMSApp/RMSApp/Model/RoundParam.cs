﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RMSApp
{
    public class RoundParam
    {
        
        public int RoundId { get; set; }        
        public string Name { get; set; }
        public string FeedBack { get; set; }
        public int? UserId { get; set; }
        public int? CandidateId { get; set; }
        public int? CreatedBy { get; set; }
        public int? ModifiedBy { get; set; }
        public bool? IsActive { get; set; }
    }
}
