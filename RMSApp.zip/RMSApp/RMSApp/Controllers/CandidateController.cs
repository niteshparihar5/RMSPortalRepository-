﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using RMSDal;
namespace RMSApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CandidateController : ControllerBase
    {
        private readonly ICandidateRepository candidateRepository;
        public CandidateController(ICandidateRepository _candidateRepository)
        {
            this.candidateRepository = _candidateRepository;
        }

        [HttpPost]
        [Route("CreateCandidate")]
        public async Task<IActionResult> CreateCandidate([FromBody]CandidateParam candidateParam)
        {
            Candidates candidates = new Candidates();
            candidates.Name = candidateParam.Name;
            candidates.Email = candidateParam.Email;
            candidates.Mobile = candidateParam.Mobile;
            candidates.Address = candidateParam.Address;
            candidates.KeySkill = candidateParam.KeySkill;
            candidates.CreatedBy = candidateParam.CreatedBy;
            candidates.CreatedDate = DateTime.Now;
            candidates.IsActive = true;
            return Ok(await candidateRepository.CreateCandidate(candidates));        
        }
    }
}