﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using RMSDal;
namespace RMSApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILoginRepository loginRepository;
        public LoginController(ILoginRepository _loginRepository)
        {
            this.loginRepository = _loginRepository;

        }
        [HttpGet]
        [Route("GetAllUser")]
        public async Task<IActionResult> GetAllUser()
        { 
                var result = await this.loginRepository.GetAllUser();
                return Ok(result);            
        }
        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login([FromBody]LoginParam loginParam)
        {          
            return Ok(await this.loginRepository.Login(loginParam.Email, loginParam.Password));
        }
    }
}