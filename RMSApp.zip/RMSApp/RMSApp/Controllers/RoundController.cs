﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RMSDal;
namespace RMSApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoundController : ControllerBase
    {

        private readonly IRoundRepository roundRepository;
        private readonly ILoginRepository loginRepository;
        public RoundController(IRoundRepository _roundRepository, ILoginRepository _loginRepository)
        {
            this.roundRepository = _roundRepository;
            this.loginRepository = _loginRepository;
        }

        [HttpGet]
        [Route("GetAllCandidate")]
        public async Task<IActionResult> GetAllCandidate()
        {
            return Ok(await this.roundRepository.GetAllCandidate());
        }

        [HttpGet]
        [Route("GetCandidateById/{id}")]
        public async Task<IActionResult> GetCandidateById(int id)
        {
            return Ok(await this.roundRepository.GetCandidateById(id));
        }

        [HttpPost]
        [Route("CreateRound")]
        public async Task<IActionResult> CreateRound([FromBody]RoundParam roundParam)
        {
            Rounds rounds = new Rounds();
            rounds.Name = roundParam.Name;
            rounds.FeedBack = roundParam.FeedBack;
            rounds.UserIdFk = roundParam.UserId;
            rounds.CandidateIdFk = roundParam.CandidateId;
            rounds.CreatedBy = roundParam.CreatedBy;
            rounds.CreatedDate = DateTime.Now;
            rounds.IsActive = true;
            return Ok(await this.roundRepository.CreateRound(rounds));
        }

        [HttpPut]
        [Route("UpdateRound/{roundId}")]
        public async Task<IActionResult> UpdateRound([FromBody]RoundParam roundParam)
        {
            Rounds rounds = new Rounds();
            rounds.Name = roundParam.Name;
            rounds.RoundId = roundParam.RoundId;          
            rounds.FeedBack = roundParam.FeedBack;                
            rounds.UserIdFk = roundParam.UserId;
            rounds.CandidateIdFk = roundParam.CandidateId;
            rounds.ModifiedBy = roundParam.ModifiedBy;
            rounds.IsActive = roundParam.IsActive;
            return Ok(await this.roundRepository.UpdateRound(rounds));
        }

        [HttpGet]
        [Route("GetRoundByCandidateId/{candidateId}")]
        public async Task<IActionResult> GetRoundByCandidateId(int candidateId)
        {
            return Ok(await this.roundRepository.GetRoundByCandidateId(candidateId));
        }

        [HttpGet]
        [Route("GetRoundByRoundId/{roundId}")]
        public async Task<IActionResult> GetRoundByRoundId(int roundId)
        {
            return Ok(await this.roundRepository.GetRoundByRoundId(roundId));
        }

        [HttpGet]
        [Route("GetRoundByInterviewerId/{interviewerId}")]
        public async Task<IActionResult> GetRoundByInterviewerId(int interviewerId)
        {
            return Ok(await this.roundRepository.GetRoundByInterviewerId(interviewerId));
        }
    }
}