using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RMSDal;

namespace RMSApp
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<RMS_DBContext>(opts => opts.UseSqlServer(Configuration["ConnectionStrings:RMSDBConnection"]));
            services.AddScoped<ILoginRepository, LoginRepository>();
            services.AddScoped<IRoundRepository, RoundRepository>();
            services.AddScoped<IMasterRepository, MasterRepository>();
            services.AddScoped<ICandidateRepository, CandidateRepository>();
            services.AddCors(options =>
            {
                options.AddPolicy("AllowOrigin",
                    builder =>
                    {
                        builder.WithOrigins("*")
                       .AllowAnyHeader().AllowAnyMethod();
                    });
            });
            RegisterSwaggerApiSetting(services);
            services.AddControllers().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
        }
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //Swagger config
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1.0/swagger.json", "RMSAPI");
            });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            // Global Exception
            app.UseMiddleware(typeof(ExceptionHandlers));

            app.UseCors("AllowOrigin");
            app.UseRouting();
            app.UseAuthorization();            
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
        //SwaggerApi Setting
        private void RegisterSwaggerApiSetting(IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1.0", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "RMSAPI", Version = "1.0" });
            });
        }
    }   
}
