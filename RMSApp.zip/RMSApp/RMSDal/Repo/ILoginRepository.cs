﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RMSDal
{
    public interface ILoginRepository
    {
        Task<List<LoginView>> GetAllUser();
        Task<LoginView> Login(string emailId, string password);
    }
}
