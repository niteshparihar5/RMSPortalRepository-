﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RMSDal
{
    public class CandidateRepository:ICandidateRepository
    {
        private readonly RMS_DBContext rMS_DBContext;
        public CandidateRepository(RMS_DBContext _rMS_DBContext)
        {
            this.rMS_DBContext = _rMS_DBContext;
        }
        public async Task<int> CreateCandidate(Candidates candidates)
        {
            await this.rMS_DBContext.Candidates.AddAsync(candidates);
            await this.rMS_DBContext.SaveChangesAsync();
            return candidates.CandidateId;
        }   
    }
}
