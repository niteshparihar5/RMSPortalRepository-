﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RMSDal
{
    public class LoginRepository:ILoginRepository
    {
        private readonly RMS_DBContext rMS_DBContext;    

        public LoginRepository(RMS_DBContext _rMS_DBContext)
        {
            this.rMS_DBContext = _rMS_DBContext;
        }
        public async Task<List<LoginView>> GetAllUser()
        {           
            return await(from x in this.rMS_DBContext.Users
                         join um in this.rMS_DBContext.UserMappings on x.UserId equals um.UserIdFk
                         join role in this.rMS_DBContext.Roles on um.RoleIdFk equals role.RoleId                        
                         orderby x.Name
                         select new LoginView
                         {
                             UserId = x.UserId,
                             UserName = x.Name,
                             RoleId = role.RoleId,
                             RoleName = role.Name,
                         }).ToListAsync();

        }

        public async Task<LoginView> Login(string emailId,string password)
        {           
                return await (from x in this.rMS_DBContext.Users
                              join um in this.rMS_DBContext.UserMappings on x.UserId equals um.UserIdFk
                              join role in this.rMS_DBContext.Roles on um.RoleIdFk equals role.RoleId
                              where x.Email.Equals(emailId) && x.Password.Equals(password)
                              select new LoginView
                              {
                                  UserId = x.UserId,
                                  UserName = x.Name,
                                  RoleId = role.RoleId,
                                  RoleName = role.Name,
                              }).FirstOrDefaultAsync(); 
        }
    }
}
