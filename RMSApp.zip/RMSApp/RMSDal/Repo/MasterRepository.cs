﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMSDal
{
   public class MasterRepository : IMasterRepository
    {

        private readonly RMS_DBContext rMS_DBContext;
        public MasterRepository(RMS_DBContext _rMS_DBContext)
        {
            this.rMS_DBContext = _rMS_DBContext;
        }
        public async Task<List<RoleView>> GetAllRole()
        {
            return await (from r in rMS_DBContext.Roles
                         orderby r.Name ascending
                          select new RoleView
                          {
                              RoleId = r.RoleId,
                              Name = r.Name                             
                          }).ToListAsync();
        }
    }
}
