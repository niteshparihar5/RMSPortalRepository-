﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMSDal
{
    public class RoundRepository : IRoundRepository
    {
        private readonly RMS_DBContext rMS_DBContext;
        public RoundRepository(RMS_DBContext _rMS_DBContext)
        {
            this.rMS_DBContext = _rMS_DBContext;
        }
        public async Task<List<CandidateView>> GetAllCandidate()
        {
            return await (from c in this.rMS_DBContext.Candidates
                          orderby c.CandidateId descending
                          select new CandidateView
                          {
                              CandidateId = c.CandidateId,
                              Name = c.Name,
                              Email = c.Email,
                              Mobile = c.Mobile,
                              Address = c.Address,
                              KeySkill = c.KeySkill
                          }).ToListAsync();
        }

        public async Task<CandidateView> GetCandidateById(int id)
        {
            return await (from c in this.rMS_DBContext.Candidates
                          where c.CandidateId.Equals(id)
                          select new CandidateView
                          {
                              CandidateId = c.CandidateId,
                              Name = c.Name,
                              Email = c.Email,
                              Mobile = c.Mobile,
                              Address = c.Address,
                              KeySkill = c.KeySkill
                          }).FirstOrDefaultAsync();
        }

        public async Task<int> CreateRound(Rounds rounds)
        {
            await this.rMS_DBContext.Rounds.AddAsync(rounds);
            await this.rMS_DBContext.SaveChangesAsync();
            return rounds.RoundId;
        }
        public async Task<List<RoundView>> GetRoundByCandidateId(int candidateId)
        {
            return await (from r in this.rMS_DBContext.Rounds
                          join u in this.rMS_DBContext.Users on r.UserIdFk equals u.UserId
                          where r.CandidateIdFk.Equals(candidateId)
                          orderby r.RoundId descending
                          select new RoundView
                          {
                              RoundId = r.RoundId,
                              Name = r.Name,
                              FeedBack = r.FeedBack,
                              InterviewerId = r.UserIdFk,
                              CandidateId = r.CandidateIdFk,
                              InterviewerName = u.Name,
                              IsActive = r.IsActive
                          }).ToListAsync();
        }

        public async Task<int> UpdateRound(Rounds rounds)
        {
            string status = string.Empty;
            Candidates candidates = new Candidates();
            this.rMS_DBContext.Rounds.Update(rounds);
            await this.rMS_DBContext.SaveChangesAsync();

            var toCandidateemail = (from r in this.rMS_DBContext.Rounds
                                    join c in this.rMS_DBContext.Candidates on r.CandidateIdFk equals c.CandidateId
                                    select new
                                    { c.Email
                                    }).FirstOrDefault();
            var toCandidateName = (from r in this.rMS_DBContext.Rounds
                                   join c in this.rMS_DBContext.Candidates on r.CandidateIdFk equals c.CandidateId
                                   select new
                                   {
                                       c.Name,
                                   }).FirstOrDefault().Name;

            var tomail = (from r in this.rMS_DBContext.Rounds
                          join u in this.rMS_DBContext.Users on r.UserIdFk equals u.UserId
                          where r.RoundId.Equals(rounds.RoundId)
                          select new { u.Email }).ToList();

            status = rounds.IsActive == true ? "Selected" : "Rejected";
            tomail.Add(toCandidateemail);
            MailTemplate.RoundUpdateNotification(tomail, rounds.FeedBack, status, toCandidateName);
            return rounds.RoundId;
        }

        public async Task<RoundView> GetRoundByRoundId(int roundId)
        {
            return await (from r in this.rMS_DBContext.Rounds
                          join u in this.rMS_DBContext.Users on r.UserIdFk equals u.UserId
                          join c in this.rMS_DBContext.Candidates on r.CandidateIdFk equals c.CandidateId
                          where r.RoundId.Equals(roundId)
                          orderby r.RoundId descending
                          select new RoundView
                          {
                              RoundId = r.RoundId,
                              Name = r.Name,
                              FeedBack = r.FeedBack,
                              InterviewerId = r.UserIdFk,
                              CandidateId = r.CandidateIdFk,
                              CandidateName = c.Name,
                              IsActive = r.IsActive
                          }).FirstOrDefaultAsync();
        }

        public async Task<List<RoundView>> GetRoundByInterviewerId(int interviewerId)
        {
            return await (from u in this.rMS_DBContext.Users
                          join r in this.rMS_DBContext.Rounds on u.UserId equals r.UserIdFk
                          join c in this.rMS_DBContext.Candidates on r.CandidateIdFk equals c.CandidateId
                          where u.UserId.Equals(interviewerId)
                          orderby r.RoundId descending
                          select new RoundView
                          {
                              RoundId = r.RoundId,
                              Name = r.Name,
                              FeedBack = r.FeedBack,
                              InterviewerId = r.UserIdFk,
                              CandidateId = r.CandidateIdFk,
                              CandidateName = c.Name,
                              KeySkill = c.KeySkill,
                              IsActive = r.IsActive
                          }).ToListAsync();
        }

       
    }
}
