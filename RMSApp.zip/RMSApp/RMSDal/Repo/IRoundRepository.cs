﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RMSDal
{
    public interface IRoundRepository
    {
        Task<List<CandidateView>> GetAllCandidate();
        Task<CandidateView> GetCandidateById(int id);
        Task<int> CreateRound(Rounds rounds);
        Task<List<RoundView>> GetRoundByCandidateId(int candidateId);
        Task<int> UpdateRound(Rounds rounds);
        Task<RoundView> GetRoundByRoundId(int roundId);
        Task<List<RoundView>> GetRoundByInterviewerId(int interviewerId);
    }
}
