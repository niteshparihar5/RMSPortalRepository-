﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace RMSDal
{
    public partial class RMS_DBContext : DbContext
    {
        public RMS_DBContext()
        {
        }

        public RMS_DBContext(DbContextOptions<RMS_DBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Candidates> Candidates { get; set; }
        public virtual DbSet<Roles> Roles { get; set; }
        public virtual DbSet<Rounds> Rounds { get; set; }
        public virtual DbSet<UserMappings> UserMappings { get; set; }
        public virtual DbSet<Users> Users { get; set; }      

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Candidates>(entity =>
            {
                entity.HasKey(e => e.CandidateId);

                entity.Property(e => e.Address)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("date");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.KeySkill)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("date");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Roles>(entity =>
            {
                entity.HasKey(e => e.RoleId);

                entity.Property(e => e.CreatedDate).HasColumnType("date");

                entity.Property(e => e.ModifiedDate).HasColumnType("date");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Rounds>(entity =>
            {
                entity.HasKey(e => e.RoundId);

                entity.Property(e => e.CandidateIdFk).HasColumnName("CandidateId_FK");

                entity.Property(e => e.CreatedDate).HasColumnType("date");

                entity.Property(e => e.FeedBack)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserIdFk).HasColumnName("UserId_FK");

                entity.HasOne(d => d.CandidateIdFkNavigation)
                    .WithMany(p => p.Rounds)
                    .HasForeignKey(d => d.CandidateIdFk)
                    .HasConstraintName("FK__Rounds__Candidat__68487DD7");

                entity.HasOne(d => d.UserIdFkNavigation)
                    .WithMany(p => p.Rounds)
                    .HasForeignKey(d => d.UserIdFk)
                    .HasConstraintName("FK__Rounds__UserId_F__693CA210");
            });

            modelBuilder.Entity<UserMappings>(entity =>
            {
                entity.HasKey(e => e.UserMappingId);

                entity.ToTable("User_Mappings");

                entity.Property(e => e.RoleIdFk).HasColumnName("RoleId_FK");

                entity.Property(e => e.UserIdFk).HasColumnName("UserId_FK");

                entity.HasOne(d => d.RoleIdFkNavigation)
                    .WithMany(p => p.UserMappings)
                    .HasForeignKey(d => d.RoleIdFk)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__User_Mapp__RoleI__4222D4EF");

                entity.HasOne(d => d.UserIdFkNavigation)
                    .WithMany(p => p.UserMappings)
                    .HasForeignKey(d => d.UserIdFk)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__User_Mapp__UserI__412EB0B6");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.Property(e => e.Address)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("date");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("date");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
