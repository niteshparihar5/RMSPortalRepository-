﻿using System;
using System.Collections.Generic;

namespace RMSDal
{
    public partial class UserMappings
    {
        public int UserMappingId { get; set; }
        public int UserIdFk { get; set; }
        public int RoleIdFk { get; set; }

        public virtual Roles RoleIdFkNavigation { get; set; }
        public virtual Users UserIdFkNavigation { get; set; }
    }
}
