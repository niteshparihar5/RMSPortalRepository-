﻿using System;
using System.Collections.Generic;

namespace RMSDal
{
    public partial class Rounds
    {
        public int RoundId { get; set; }
        public string Name { get; set; }
        public string FeedBack { get; set; }
        public int? UserIdFk { get; set; }
        public int? CandidateIdFk { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        public int? ModifiedDate { get; set; }
        public bool? IsActive { get; set; }

        public virtual Candidates CandidateIdFkNavigation { get; set; }
        public virtual Users UserIdFkNavigation { get; set; }
    }
}
