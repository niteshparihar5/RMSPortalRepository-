﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RMSDal
{
   public static class MailTemplate
    {
        public static void RoundUpdateNotification(dynamic toMailList, string feedback, string status, dynamic candidateName)
        {
            string body = string.Empty;
            string subject = "Interview Feedback mail.";
            body += " Hi All  <br/> <br/>";
            body += candidateName + " has " + status + " for this round. <br/> <br/> ";
            if (!string.IsNullOrEmpty(feedback)) { body += "Interviewer Comment: " + feedback + "<br/> <br/> "; }
            body += " Thanks & Regards ,<br/> <br/> XYZ Team ";
            Common.SendMail(toMailList, body, subject);
        }
    }
}
