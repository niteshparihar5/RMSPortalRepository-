﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;
namespace RMSDal
{
    public static class Common
    {
        //Niteshkumar.Singh@NIIT-Tech.com


        //public static void SendMail(, string Title, string attachment)
        public static void SendMail(dynamic tomail, string body, string subject)
        {            
            MailMessage mail = new MailMessage();
            
            foreach (var item in tomail)
            {
                mail.To.Add(item.Email);
            }
            mail.From = new MailAddress("cbretest2019@gmail.com");
            mail.Subject = subject;
            mail.IsBodyHtml = true;
            mail.Body = body;
            mail.IsBodyHtml = true;           
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 25;
            smtp.Credentials = new System.Net.NetworkCredential("cbretest2019@gmail.com", "cbre@123");
            smtp.EnableSsl = true;
            smtp.Send(mail);
        }

       

    }
}
