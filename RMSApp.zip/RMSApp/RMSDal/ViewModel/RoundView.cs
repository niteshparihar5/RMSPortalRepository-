﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RMSDal
{
    public class RoundView
    {
        public int RoundId { get; set; }
        public string Name { get; set; }
        public string InterviewerName { get; set; }
        public string FeedBack { get; set; }
        public string CandidateName { get; set; }
        public int? InterviewerId { get; set; }
        public int? CandidateId { get; set; }
        public string KeySkill { get; set; }
        public bool? IsActive { get; set; }
    }
}
