﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RMSDal
{
   public class RoleView
    {
        public int RoleId { get; set; }
        public string Name { get; set; }
    }
}
