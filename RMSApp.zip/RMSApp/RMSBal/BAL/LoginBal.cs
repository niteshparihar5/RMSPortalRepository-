﻿using System;
using System.Collections.Generic;
using System.Text;
using RMSBal;
namespace RMSBal
{
   public class LoginBal
    {
        private readonly ILoginRepository loginRepository;
        public LoginBal()
        {         
        
        }

    }
}
