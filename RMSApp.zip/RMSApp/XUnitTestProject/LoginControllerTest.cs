﻿using System;
using System.Collections.Generic;
using System.Text;
using RMSApp;
using RMSDal;
using Xunit;
using Moq;
using RMSApp.Controllers;



namespace XUnitTestProject
{
    public class LoginControllerTest 
    {       
        private readonly LoginController _loginController;
        private readonly Mock<ILoginRepository> mockILoginRepository = new Mock<ILoginRepository>();          

        public LoginControllerTest()
        {
            _loginController = new LoginController(mockILoginRepository.Object);
        }

        [Fact] 
        public async void Test_GetAllUser()
        {
            List<LoginView> lstloginViews = new List<LoginView>();
            lstloginViews.Add(new LoginView { UserId = 1, RoleId = 1, RoleName = "HR", UserName = "HR" });
            lstloginViews.Add(new LoginView { UserId = 2, RoleId = 2, RoleName = "Interviewer", UserName = "Interviewer" }); 
            mockILoginRepository.Setup(x => x.GetAllUser()).ReturnsAsync(lstloginViews);
            var result = await _loginController.GetAllUser(); 
            Assert.NotNull(result);           
        }
    }
}
