import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {LoginService} from "../app/Services/login.service";
import {Users} from '../app/model/users';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'RMSPortal';
  userName:string; 
  roleId:number;  
  showBanner:boolean=false; 
  currentUser: Users;
  user: any;
  constructor(private router: Router,private loginService: LoginService) {
    // this.loginService.currentUser.subscribe(x => this.currentUser = x);
    // this.currentUser = this.loginService.currentUserValue;
   }

   ngOnInit()
   {
    this.getCurrentUser();
    
   }

logout() {  
    this.loginService.logout();
    this.showBanner=false;
    
    this.router.navigate(['/app-login']);
  }
  public getCurrentUser()
  {  debugger;
    if(this.loginService.currentUser!=undefined){ 
    this.loginService.currentUser.subscribe(data=>{ 
      this.user= data; 
     this.userName= data.userName;
        this.roleId=data.roleId;
     this.showBanner=true;  
     
    });
  }
  }
}


 