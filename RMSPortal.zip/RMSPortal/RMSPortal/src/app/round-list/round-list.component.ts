import { Component, OnInit,ViewChild } from '@angular/core';
import {Router,ActivatedRoute } from "@angular/router";
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import {Round} from "../model/round";
import {RoundService} from "../Services/round.service";
//import {Candidate} from "../model/candidate";
@Component({
  selector: 'app-round-list',
  templateUrl: './round-list.component.html',
  styleUrls: ['./round-list.component.css']
})
export class RoundListComponent implements OnInit {
  displayedColumns: string[] =['name', 'interviewerName', 'feedBack','roundId']; 
  dataSource: MatTableDataSource<Round>;
   @ViewChild(MatPaginator,{static:true}) paginator: MatPaginator;
  @ViewChild(MatSort,{static:true}) sort: MatSort;
  candidateId:number;
  constructor(private roundService:RoundService,private _avRoute: ActivatedRoute,private router:Router) { } 

  ngOnInit(): void {

    if (this._avRoute.snapshot.queryParams["candidateId"]) {
      this.candidateId = this._avRoute.snapshot.queryParams["candidateId"];      
      } 
    this.getRoundByCandidateId();
  }

  getRoundByCandidateId()
  {    
    if(this.candidateId!=undefined){
    this.roundService.GetRoundByCandidateId(this.candidateId)
    .subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  updateInterviewRound(round)
  {     
    this.router.navigate(['app-update-round'], { queryParams: { roundId: round.roundId } });
  }
  onBack()
  { 
    this.router.navigate(['app-candidate-list']); 
  }

}
