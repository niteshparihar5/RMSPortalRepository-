import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router } from "@angular/router";
import {RoundService} from "../Services/round.service";
import {CommonService} from '../Services/common.service';
import {LoginService} from '../Services/login.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  updateFeedback: FormGroup;  
  submitted = false;
  tokenData:string;
  roundList:any;
  userList:any;
  roundId:number ;
  candidateId:number;
  interviewerId:number;
  roleId:number;
  constructor(private formBuilder: FormBuilder,private router: Router,private roundService:RoundService,private common: CommonService,private loginService:LoginService) {
   debugger;
    this.tokenData=this.common.TOKEN_DATA
    this.interviewerId=JSON.parse(localStorage[this.tokenData]).userId;
    this.roleId=JSON.parse(localStorage[this.tokenData]).roleId;
   }

  ngOnInit(): void {
    this.validation();
    this.getAllUser();
    this.GetRoundByInterviewerId();
  }
  get f() { return this.updateFeedback.controls; } 

  validation() {    
    this.updateFeedback = this.formBuilder.group({   
      candidatename: ['', Validators.required],
      candidateid: 0,
      modifiedby: 0,
      roundid: 0,   
      feedback: ['', Validators.required],   
      isactive: [true, Validators.required], 
      name: "", 
      userid:0,
    });   
  }  
  getAllUser()
  {
    this.loginService.GetAllUser().subscribe(data => {        
      this.userList=data;
    }); 
  }
  GetRoundByInterviewerId()
  {
    this.roundService.GetRoundByInterviewerId(this.interviewerId).subscribe(data => {        
          this.roundList=data;
     }); 
  }

  onSubmit()
  {
    this.submitted = true;  
    if(this.updateFeedback.invalid) { 
   return;
   }
   else{       
    let isActive=JSON.parse(this.updateFeedback.controls['isactive'].value);
    this.updateFeedback.controls['isactive'].setValue(isActive);
    this.updateFeedback.controls['userid'].setValue(parseInt(this.updateFeedback.controls['userid'].value));
     this.roundService.UpdateInterViewRound(this.updateFeedback.value).subscribe(data => {  
      this.updateFeedback.reset();
      this.updateFeedback.controls['isactive'].setValue(false); 
      this.updateFeedback.controls['userid'].setValue(0);  
      this.GetRoundByInterviewerId();
     }); 
   }  
  }
  onBack()
  { 
    this.router.navigate(['app-round-list'], { queryParams: { candidateId: this.candidateId } });
  }
  editFeedback(user)
  {
    this.candidateId=user.candidateId;
    this.updateFeedback.controls['candidatename'].setValue(user.candidateName);
    this.updateFeedback.controls['candidateid'].setValue(user.candidateId);    
    this.updateFeedback.controls['modifiedby'].setValue(this.interviewerId);
    this.updateFeedback.controls['roundid'].setValue(user.roundId);
    this.updateFeedback.controls['feedback'].setValue(user.feedBack);
    this.updateFeedback.controls['name'].setValue(user.name);
    this.updateFeedback.controls['userid'].setValue(this.interviewerId);    
    this.updateFeedback.controls['isactive'].setValue(user.isActive);  
  }
}