import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router,ActivatedRoute } from "@angular/router";
import {RoundService} from "../Services/round.service";
import {Candidate} from "../model/candidate";
import {CommonService} from '../Services/common.service';
import {LoginService} from '../Services/login.service';

@Component({
  selector: 'app-create-round',
  templateUrl: './create-round.component.html',
  styleUrls: ['./create-round.component.css']
})
export class CreateRoundComponent implements OnInit {
  createRound: FormGroup;  
  submitted = false;
  currentCandidate:Candidate;
  tokenData:string;
  userList:any;
  candidateId:number ;


  constructor(private formBuilder: FormBuilder,private router: Router,private roundService:RoundService,private common: CommonService,private loginService:LoginService) 
  {
    this.tokenData= common.TOKEN_DATA;
    
   }

  ngOnInit(): void {
    this.validation();    
   var currentCandidate=this.roundService.GetCurrentCandidate();
   if(currentCandidate!=null) { 
  this.createRound.controls['candidateid'].setValue(currentCandidate.candidateId);
  this.candidateId=currentCandidate.candidateId;
  this.createRound.controls['candidatename'].setValue(currentCandidate.name);
   }

  this.getAllUser();
  
  }
  validation() {    
    this.createRound = this.formBuilder.group({   
        candidateid: 0,
        createdby: 0,       
        userid: [1, Validators.required],
        candidatename: ['', Validators.required],
        name: ['', Validators.required],            
    });   
  }
  // convenience getter for easy access to form fields
  get f() { return this.createRound.controls; }  

  getAllUser()
  {
    this.loginService.GetAllUser().subscribe(data => {        
      this.userList=data;
    }); 
  }

  onSubmit()
  {     
    this.submitted = true;  
     if(this.createRound.invalid) { 
    return;
    }
    else{ 
    this.createRound.controls['createdby'].setValue(JSON.parse(localStorage[this.tokenData]).userId);
    this.createRound.controls['userid'].setValue(parseInt(this.createRound.controls['userid'].value));
      this.roundService.CreateInterViewRound(this.createRound.value).subscribe(data => {  
        this.router.navigate(['app-round-list'], { queryParams: { candidateId: this.candidateId } });     
      }); 
    }  
  }
  onBack()
  { 
    this.router.navigate(['app-candidate-list']); 
  }
}
