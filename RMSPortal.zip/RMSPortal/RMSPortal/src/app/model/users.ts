export class Users
{
    public userId: number;
    public userName: string;
    public roleId: number;
    public roleName: string;    
}