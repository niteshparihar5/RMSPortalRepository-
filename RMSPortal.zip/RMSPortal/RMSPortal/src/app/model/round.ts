
export class Round
    {
        public roundId :number;
        public name :string;
        public interviewerName :string;
        public feedBack :string;
        public interviewerId :number;
        public candidateId :number;
        public candidateName :string;
        public keySkill:string;
        public isActive:boolean;
    }