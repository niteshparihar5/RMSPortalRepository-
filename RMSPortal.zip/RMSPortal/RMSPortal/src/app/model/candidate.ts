
 export class Candidate
 {
     public candidateId:number;
     public name: string;
     public email: string;
     public mobile: number;
     public address : string;
     public keySkill: string;     
 }