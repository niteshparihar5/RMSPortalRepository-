import { Component, OnInit, ViewChild} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import {Router} from "@angular/router";
import {RoundService} from "../Services/round.service";
import {Candidate} from "../model/candidate";
import {MatFormFieldControl} from '@angular/material/form-field';
@Component({
  selector: 'app-candidate-list',
  templateUrl: './candidate-list.component.html',
  styleUrls: ['./candidate-list.component.css']
})
export class CandidateListComponent implements OnInit {
  
  displayedColumns: string[] =['name', 'email', 'mobile','address','keySkill','candidateId']; 
  dataSource: MatTableDataSource<Candidate>;
   @ViewChild(MatPaginator,{static:true}) paginator: MatPaginator;
  @ViewChild(MatSort,{static:true}) sort: MatSort;
 
  constructor(private router: Router,private roundService:RoundService) { }

  getAllCandidate()   {  
    this.roundService.GetAllCandidate().subscribe(data => {         
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });    
  }    
  ngOnInit() {
    this.getAllCandidate();
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  createInterviewRound(candidate) {   
   this.roundService.CurrentCandidate(candidate);   
   this.router.navigate(['app-create-round']);
  }
  viewInterviewRound(candidate) { 
    this.router.navigate(['app-round-list'], { queryParams: { candidateId: candidate.candidateId } });    
   }
   addCandidate()
   {
    this.router.navigate(['app-create-candidate']);
   }
}
