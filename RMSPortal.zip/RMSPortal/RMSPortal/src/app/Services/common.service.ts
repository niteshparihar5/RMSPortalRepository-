import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
 export class CommonService {

  public BASEURL: string = 'http://localhost:5000/api'; 
  public TOKEN_DATA:string="tokendata";
   constructor() { }
}
