import { Injectable } from '@angular/core';
import { HttpClient  } from '@angular/common/http';
import {CommonService} from './common.service';
import {Candidate} from "../model/candidate";
import {Round} from "../model/round";
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RoundService {
  baseUrl:string;  
  private candidate:Candidate;
  private currentCandidateSubject: BehaviorSubject<any>;

  constructor(private http: HttpClient,private common:CommonService) { 
    this.baseUrl= common.BASEURL;
    this.currentCandidateSubject = new BehaviorSubject<any>(this.candidate);
  }

public GetAllCandidate()
{   
  return this.http.get<Candidate[]>(`${this.baseUrl}/round/GetAllCandidate`);
}

public GetRoundByCandidateId(candidateId)
{   
  return this.http.get<Round[]>(`${this.baseUrl}/round/GetRoundByCandidateId/${candidateId}`);
}

public GetRoundByRoundId(roundId)
{   
  return this.http.get<Round>(`${this.baseUrl}/round/GetRoundByRoundId/${roundId}`);
}

public CreateInterViewRound(roundParam)
{   
  return this.http.post(`${this.baseUrl}/round/CreateRound`,roundParam);
}

public UpdateInterViewRound(roundParam:any)
{   
  return this.http.put(`${this.baseUrl}/round/UpdateRound/${roundParam.roundid}`,roundParam);
}

public GetRoundByInterviewerId(interviewerId:number)
{   
  return this.http.get<Round[]>(`${this.baseUrl}/round/GetRoundByInterviewerId/${interviewerId}`);
}

public CurrentCandidate(candidate)
{
  this.currentCandidateSubject.next(candidate);   
}
public GetCurrentCandidate()
{   
  return this.currentCandidateSubject.value;   
  }
}
