import { Injectable } from '@angular/core';
import { HttpClient  } from '@angular/common/http';
import {CommonService} from './common.service';

@Injectable({
  providedIn: 'root'
})
export class CandidateService {
  baseUrl:string;   
  tokenData:string;   
  constructor(private http: HttpClient,private common:CommonService) { 
    this.baseUrl= common.BASEURL;
  }
  public CreateCandidate(candidateParam:any)
  {
  return this.http.post(`${this.baseUrl}/candidate/CreateCandidate`,candidateParam)
  }
}
