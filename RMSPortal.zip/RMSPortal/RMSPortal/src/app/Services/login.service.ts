import { Injectable } from '@angular/core';
import { HttpClient  } from '@angular/common/http';
import {CommonService} from './common.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {Users} from '../model/users';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
    baseUrl:string;   
    tokenData:string;    
    public currentUserSubject = new BehaviorSubject([]);
    public currentUser: Observable<any>; 
    constructor(private http: HttpClient,private common:CommonService) {  
      this.baseUrl= common.BASEURL;    
      this.tokenData= common.TOKEN_DATA;
      if (localStorage.getItem(this.tokenData) != null) {     
      this.currentUserSubject = new BehaviorSubject(JSON.parse(localStorage[this.tokenData]));
      this.currentUser = this.currentUserSubject.asObservable();
      }
     
    }    
    public Login(login: any){      
      return this.http.post<any>(`${this.baseUrl}/login/Login`,login).subscribe(data => {  
        localStorage[this.common.TOKEN_DATA]= JSON.stringify(data);
        this.currentUserSubject.next(data);
        return data;
      });  
    }
    public get currentUserValue(): any {
      
      if(this.currentUserSubject!=undefined)
      return this.currentUserSubject.value;
  }
  
  logout() {    
    localStorage.clear();
    localStorage.clear();
    this.currentUserSubject.next(null);
      }
      public GetAllUser()
      {
      return this.http.get(`${this.baseUrl}/login/GetAllUser`);
      }
  }