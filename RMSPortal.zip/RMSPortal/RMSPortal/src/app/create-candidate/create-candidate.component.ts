import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router,ActivatedRoute } from "@angular/router";
import {Candidate} from "../model/candidate";
import {CommonService} from '../Services/common.service';
import {LoginService} from '../Services/login.service';
import {CandidateService} from '../Services/candidate.service';

@Component({
  selector: 'app-create-candidate',
  templateUrl: './create-candidate.component.html',
  styleUrls: ['./create-candidate.component.css']
})
export class CreateCandidateComponent implements OnInit {
  createCandidate: FormGroup;  
  submitted = false;
  tokenData:string;
  candidateId:number;
  constructor(private formBuilder: FormBuilder,private router: Router,private common: CommonService,private loginService:LoginService,private candidateService:CandidateService)
   {debugger;
     this.tokenData= common.TOKEN_DATA;
     }

  ngOnInit(): void {
    this.validation();
  }


validation() {

  this.createCandidate = this.formBuilder.group({ 
    createdby: 0,  
    name: ['', Validators.required],
    email: ['', [Validators.required,Validators.email]],       
    mobile: ['', Validators.required],
    address: ['', Validators.required],
    keySkill: ['', Validators.required],            
});   
}

get f() { return this.createCandidate.controls; }  

onSubmit()  {
  debugger;
  this.submitted = true;  
  if(this.createCandidate.invalid)
  {
    return;
  }
  else{ 
    this.createCandidate.controls['createdby'].setValue(JSON.parse(localStorage[this.tokenData]).userId);
      this.candidateService.CreateCandidate(this.createCandidate.value).subscribe(data => {  
       this.router.navigate(['app-candidate-list']);      
      }); 
    }  
  }
  onBack()
  {
    this.router.navigate(['app-candidate-list']);
  }

}
