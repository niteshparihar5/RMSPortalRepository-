import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from "./login/login.component";
import {DashBoardComponent} from "./dash-board/dash-board.component";
import {CreateRoundComponent} from "./create-round/create-round.component";
import { CandidateListComponent } from './candidate-list/candidate-list.component';
import { RoundListComponent } from './round-list/round-list.component';
import { UpdateRoundComponent } from './update-round/update-round.component';
import{AuthGuard} from './_helpers/authGuard';
import { FeedbackComponent } from './feedback/feedback.component';
import { CreateCandidateComponent } from './create-candidate/create-candidate.component';

 const routes: Routes = [
  { path: '', component: LoginComponent },
  {path : 'app-dash-board', component : DashBoardComponent, canActivate: [AuthGuard] }, 
  {path : 'app-create-round', component : CreateRoundComponent, canActivate: [AuthGuard] }, 
  {path : 'app-candidate-list', component : CandidateListComponent, canActivate: [AuthGuard] }, 
  {path : 'app-round-list', component : RoundListComponent, canActivate: [AuthGuard] }, 
  {path : 'app-update-round', component : UpdateRoundComponent, canActivate: [AuthGuard] }, 
  {path : 'app-feedback', component : FeedbackComponent, canActivate: [AuthGuard] }, 
  {path : 'app-create-candidate', component : CreateCandidateComponent, canActivate: [AuthGuard] }, 
  { path: '**', redirectTo: '' }  
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
