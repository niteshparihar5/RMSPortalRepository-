import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router,ActivatedRoute } from "@angular/router";
import {RoundService} from "../Services/round.service";
import {Candidate} from "../model/candidate";
import {CommonService} from '../Services/common.service';
import {LoginService} from '../Services/login.service';

@Component({
  selector: 'app-update-round',
  templateUrl: './update-round.component.html',
  styleUrls: ['./update-round.component.css']
})
export class UpdateRoundComponent implements OnInit {
  updateRound: FormGroup;  
  submitted = false;
  currentCandidate:Candidate;
  tokenData:string;
  userList:any;
  roundId:number ;
  candidateId:number;
  constructor(private formBuilder: FormBuilder,private _avRoute: ActivatedRoute,private router: Router,private roundService:RoundService,private common: CommonService,private loginService:LoginService)
   {
    this.tokenData= common.TOKEN_DATA;
    if (this._avRoute.snapshot.queryParams["roundId"]) {
      this.roundId = this._avRoute.snapshot.queryParams["roundId"];      
      } 
    }
  ngOnInit(): void {
    this.validation();
    this.getRoundByRoundId();
    this.getAllUser();
  }
  public getRoundByRoundId()
  {
  this.roundService.GetRoundByRoundId(this.roundId).subscribe(data=>{      
    this.updateRound.controls['modifiedby'].setValue(JSON.parse(localStorage[this.tokenData]).userId);
    this.updateRound.controls['userid'].setValue(data.interviewerId);
    this.updateRound.controls['candidatename'].setValue(data.candidateName);
    this.updateRound.controls['name'].setValue(data.name);
    this.updateRound.controls['candidateid'].setValue(data.candidateId);
    this.updateRound.controls['roundid'].setValue(data.roundId);
    this.updateRound.controls['isactive'].setValue(data.isActive);
    this.updateRound.controls['feedback'].setValue(data.feedBack);
    this.candidateId = data.candidateId;
  });
}

validation() {    
  this.updateRound = this.formBuilder.group({   
      candidateid: 0,
      modifiedby: 0,
      roundid: 0,
      feedback: null,
      userid: [1, Validators.required],
      candidatename: ['', Validators.required],
      name: ['', Validators.required],
      isactive: [false, Validators.required],            
  });   
}

getAllUser()
  {
    this.loginService.GetAllUser().subscribe(data => {        
      this.userList=data;
    }); 
  }

  get f() { return this.updateRound.controls; }  
  onSubmit()
  {
    this.submitted = true;  
    if(this.updateRound.invalid) { 
   return;
   }
   else{ 
    //let isActive=this.updateRound.controls['isactive'].value =="true" ? true :false;
    let isActive= JSON.parse(this.updateRound.controls['isactive'].value);
    this.updateRound.controls['isactive'].setValue(isActive);
    this.updateRound.controls['userid'].setValue(parseInt(this.updateRound.controls['userid'].value));
     this.roundService.UpdateInterViewRound(this.updateRound.value).subscribe(data => {  
       this.router.navigate(['app-round-list'], { queryParams: { candidateId: this.candidateId } });     
     }); 
   }  
  }

  onBack()
  { 
    this.router.navigate(['app-round-list'], { queryParams: { candidateId: this.candidateId } });
  }

}
