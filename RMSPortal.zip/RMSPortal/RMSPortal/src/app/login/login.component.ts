import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from "@angular/forms";
import {Router,ActivatedRoute } from "@angular/router";
import {LoginService} from "../Services/login.service";
import {CommonService} from '../Services/common.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  invalidLogin: boolean = false;  
  returnUrl: string;
    constructor(private loginService: LoginService ,private common:CommonService,private formBuilder: FormBuilder,
      private router: Router,private route: ActivatedRoute,) { 
       
        if (this.loginService.currentUserValue) {
          this.router.navigate(['/app-login']);
      }  
  }
  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }
  onSubmit():void{ 
    let result=this.loginService.Login(this.loginForm.value);
      if(result!=null )
      { 
        this.router.navigate(['app-dash-board']);
      }   
  }
}
